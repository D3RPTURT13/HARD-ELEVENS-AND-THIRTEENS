/**
 * This is a class that plays the GUI version of the HARD Elevens game.
 * See accompanying documents OF HOW NOT TO BE SCRUB.
 */
public class ElevensHARDGUIRunner {

	/**
	 * Plays the GUI version of HARD Elevens.
	 * @param args is not used.
	 */
	public static void main(String[] args) {
		Board board = new ElevensHARDBoard();
		CardGameGUI gui = new CardGameGUI(board);
		gui.displayGame();
	}
}
