
/**
 * This is a class that plays the GUI version of the Thirteens HARD game.
 */
public class ThirteensHARDGUIRunner {

	/**
	 * Plays the GUI version of HARD Thirteens.
	 * @param args is not used.
	 */
	public static void main(String[] args) {
		Board board = new ThirteensHARDBoard();
		CardGameGUI gui = new CardGameGUI(board);
		gui.displayGame();
	}
}